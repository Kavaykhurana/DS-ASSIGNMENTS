#include<iostream> 
using namespace std; 
int main(){ 
    string a="abc"; 
    string b="def"; 
    cout<<a+b; 
} 
